// Initialize Booqable with your company ID
var booqableOptions = {
    company: '6342e9fe-5389-4403-9cb5-9bbdd1de2640'
  };
  
  // Load the Booqable script
  (function() {
    var script = document.createElement('script');
    script.src = 'https://6342e9fe-5389-4403-9cb5-9bbdd1de2640.assets.booqable.com/v2/booqable.js';
    script.async = true;
    document.head.appendChild(script);
  })();